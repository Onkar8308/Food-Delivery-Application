export class DummyPayment {
    public static  personName:string="Nidhi";
    public static cardNum:string = "123456789123";
    public static expiryDate:string = "08/2023";
    public static cvv:any="123";
}
