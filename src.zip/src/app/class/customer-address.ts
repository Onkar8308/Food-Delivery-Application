export class CustomerAddress {
    constructor(
        addressid:number,
        area:string,
        city:string,
        state:string,
        country:string,
        pincode:number
    ){  }

}
