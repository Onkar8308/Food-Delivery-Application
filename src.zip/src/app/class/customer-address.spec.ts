import { CustomerAddress } from './customer-address';

describe('CustomerAddress', () => {
  it('should create an instance', () => {
    expect(new CustomerAddress()).toBeTruthy();
  });
});
