export class Order {
    constructor(
        public ordersid:number,
        public ordersdate:Date,
        public ordersstatus:string
    ){}
}
